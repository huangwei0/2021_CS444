#include "types.h"
#include "user.h"

int main(int argc, char *argv[]){

	int i;
	for(i = 0; i < 10;i++)
	printf(1, "random number is: %d\n", random());

	exit();
	
}